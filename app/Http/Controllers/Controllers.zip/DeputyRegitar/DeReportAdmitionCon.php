<?php

namespace App\Http\Controllers\DeputyRegitar;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class DeReportAdmitionCon extends Controller
{
    //
}
