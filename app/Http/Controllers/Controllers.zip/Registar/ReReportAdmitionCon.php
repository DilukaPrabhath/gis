<?php

namespace App\Http\Controllers\Registar;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ReReportAdmitionCon extends Controller
{
    //
}
