@extends('data_entry.layout.master')
@section('content')
<div class="page-content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">

                        <h4 class="mt-0 header-title">Application Payment Table</h4>


                        <table id="datatable" class="table table-bordered dt-responsive nowrap" style="border-collapse: collapse; border-spacing: 0; width: 100%;">
                            <thead>
                            <tr>
                                <th>Recipt No</th>
                                <th>Inquery Number</th>
                                <th>Price</th>
                                <th>Date</th>
                                <th>Action</th>
                            </tr>
                            </thead>


                            <tbody>
                                @foreach ($tbl as $value)
                                        <tr>
                                            <td>{{$value->slip_num}}</td>
                                            <td>{{$value->inq_id}}</td>
                                            <td>{{$value->price}}</td>
                                            <td>@php
                                                $newDateTime = date('Y-m-d h:i A', strtotime($value->created_at));
                                                @endphp
                                               {{ $newDateTime }}</td>

                                            <td>
                                                <a href="{{url('data_entry/application_pay/print')}}/{{$value->id}}" type="button" class="btn btn-dropbox">
                                                    <i class="fab far fa-eye" style="color: white; font-size:8px;"></i>
                                                </a>
                                                <a href="{{url::to(data_entry/application_pay/print/.$value->id)}}" type="button" class="btn btn-danger">
                                                    <i class="fab fas fa-pencil-alt" style="color: white; font-size:8px;"></i>
                                                </a>
                                            </td>
                                        </tr>
                                @endforeach
                            </tbody>
                        </table>

                    </div>
                </div>
            </div> <!-- end col -->
        </div> <!-- end row -->

    </div>
    @stop

    @section('button')
    <div class="float-right align-item-center mt-2">
        <a href="{{url('data_entry/application_pay/create')}}" class="btn btn-info px-4 align-self-center report-btn">Add</a>
    </div>
    @stop
